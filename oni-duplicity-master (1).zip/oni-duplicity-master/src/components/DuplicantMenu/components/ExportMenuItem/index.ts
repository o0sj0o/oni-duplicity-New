import ExportMenuItem from "./component";
import connectExportMenuItem from "./connector";

export default connectExportMenuItem(ExportMenuItem);
