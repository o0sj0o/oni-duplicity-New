import CloneMenuItem from "./component";
import connectCloneMenuItem from "./connector";

export default connectCloneMenuItem(CloneMenuItem);
