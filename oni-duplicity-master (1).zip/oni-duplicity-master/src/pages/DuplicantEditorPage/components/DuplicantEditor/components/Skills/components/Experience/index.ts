import Experience from "./component";
import connectExperience from "./connector";
export default connectExperience(Experience);
