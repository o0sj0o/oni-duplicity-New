import AbstractLoadButton from "./component";
export default AbstractLoadButton;