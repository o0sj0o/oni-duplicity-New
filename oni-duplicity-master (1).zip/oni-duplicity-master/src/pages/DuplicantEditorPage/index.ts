import DuplicantEditorPage from "./DuplicantEditorPage";
export default DuplicantEditorPage;
