import DuplicantListItem from "./DuplicantListItem";
export default DuplicantListItem;
