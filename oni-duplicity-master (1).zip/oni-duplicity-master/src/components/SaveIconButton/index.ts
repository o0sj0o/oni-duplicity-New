import SaveIconButton from "./component";
import connectSaveIconButton from "./connector";

export default connectSaveIconButton(SaveIconButton);
