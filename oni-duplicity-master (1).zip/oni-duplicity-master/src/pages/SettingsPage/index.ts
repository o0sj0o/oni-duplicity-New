import SettingsPage from "./SettingsPage";
export default SettingsPage;
