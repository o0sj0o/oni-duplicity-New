import LoadExampleButton from "./component";
import connectLoadExampleButton from "./connector";

export default connectLoadExampleButton(LoadExampleButton);
