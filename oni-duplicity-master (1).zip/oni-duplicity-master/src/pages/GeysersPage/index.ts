import GeysersPage from "./GeysersPage";
export default GeysersPage;
