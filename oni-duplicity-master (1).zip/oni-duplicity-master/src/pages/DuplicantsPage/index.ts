import DuplicantsPage from "./DuplicantsPage";
export default DuplicantsPage;
