import Traits from "./Traits";
export default Traits;
