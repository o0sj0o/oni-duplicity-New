import CreaturesPage from "./CreaturesPage";
export default CreaturesPage;
