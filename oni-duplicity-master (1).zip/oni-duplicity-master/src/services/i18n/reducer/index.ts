import setLanguageReducer from "./set-language";

export default setLanguageReducer;
