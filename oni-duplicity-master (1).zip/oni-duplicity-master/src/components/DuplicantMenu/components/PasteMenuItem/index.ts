import PasteMenuItem from "./component";
import connectPasteMenuItem from "./connector";

export default connectPasteMenuItem(PasteMenuItem);
