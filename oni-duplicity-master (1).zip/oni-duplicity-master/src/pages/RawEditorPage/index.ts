import connectRawEditorPage from "./connector";
import RawEditorPage from "./RawEditorPage";
export default connectRawEditorPage(RawEditorPage);
