import ChangelogPage from "./ChangelogPage";
export default ChangelogPage;
