import DuplicantMenu from "./component";
export default DuplicantMenu;
