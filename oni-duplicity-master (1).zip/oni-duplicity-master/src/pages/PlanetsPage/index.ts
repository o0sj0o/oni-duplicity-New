import PlanetsPage from "./PlanetsPage";
export default PlanetsPage;