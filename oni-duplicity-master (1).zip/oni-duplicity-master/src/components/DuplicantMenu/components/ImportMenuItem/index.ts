import ImportMenuItem from "./component";
import connectImportMenuItem from "./connector";

export default connectImportMenuItem(ImportMenuItem);
