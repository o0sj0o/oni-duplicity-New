import ExampleChip from "./component";
import connectExampleChip from "./connector";

export default connectExampleChip(ExampleChip);
