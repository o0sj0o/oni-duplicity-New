import LoadButton from "./component";

export default LoadButton;
