import ImportWarningDialog from "./component";
import connectImportWarningDialog from "./connector";
export default connectImportWarningDialog(ImportWarningDialog);
