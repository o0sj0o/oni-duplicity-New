// TODO: Get a list of all creatures, including variants.
export const CREATURE_GAMEOBJECT_TYPES = ["Pacu", "Mole", "LightBug"];
