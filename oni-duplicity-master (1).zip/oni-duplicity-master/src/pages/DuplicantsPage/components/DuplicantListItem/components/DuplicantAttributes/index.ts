import DuplicantAttributes from "./DuplicantAttributes";
export default DuplicantAttributes;
