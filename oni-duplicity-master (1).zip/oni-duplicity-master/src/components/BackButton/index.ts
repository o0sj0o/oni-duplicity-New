import BackButton from "./component";
import connectBackButton from "./connector";

export default connectBackButton(BackButton);
