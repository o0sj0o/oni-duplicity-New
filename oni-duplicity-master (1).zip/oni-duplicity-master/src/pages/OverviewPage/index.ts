import OverviewPage from "./component";
import connectOverviewPage from "./connector";

export default connectOverviewPage(OverviewPage);
