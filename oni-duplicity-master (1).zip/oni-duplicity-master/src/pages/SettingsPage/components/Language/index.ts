import Language from "./component";
import connectLanguage from "./connector";
export default connectLanguage(Language);
