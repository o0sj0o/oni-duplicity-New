export const ACTION_INITIALIZE = "@common/initialize" as const;
export const initialize = () => ({
  type: ACTION_INITIALIZE
});
