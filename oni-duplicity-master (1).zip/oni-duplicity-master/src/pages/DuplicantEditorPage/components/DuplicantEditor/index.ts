import DuplicantEditor from "./DuplicantEditor";
export default DuplicantEditor;
