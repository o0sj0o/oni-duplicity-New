import LoadingDialog from "./component";
import connectLoadingDialog from "./connector";

export default connectLoadingDialog(LoadingDialog);
