import CopyMenuItem from "./component";
import connectCopyMenuItem from "./connector";

export default connectCopyMenuItem(CopyMenuItem);
